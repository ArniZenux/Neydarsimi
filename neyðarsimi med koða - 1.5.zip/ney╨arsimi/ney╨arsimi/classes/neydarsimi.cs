﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using System.Windows.Forms;

namespace neyðarsimi
{
    class neydarsimi : Global
    {
        #region "Class"
        dbConnection clsDatabase = new dbConnection();
        #endregion 

        #region "VARIABLES"
        public int numer;
        public string kennitala;
        public string byrja;
        public int day;
        public int month;
        public int year;
        public int day_DateTime_Now;
        public int month_DateTime_Now;
        public int year_DateTime_Now;
        string[] dagur;
        public string endir;
        public string timi_byrja;
        public string timi_endir;
        public string vettvangur;
        public string strengur;
        public string monthString;

        ListViewItem list;
        DateTime dt;
        #endregion

        #region "PROPERTIES"
        /*public void setNumber(int number){
            this.number = number; 
        }*/

        public void setKennitala(string kennitala)
        {
            this.kennitala = kennitala; 
        }

        public void setByrja(string byrja)
        {
            this.byrja = byrja; 
        }

        public void setEndir(string endir)
        {
            this.endir = endir;
        }

        public void setTimiByrja(string timi_byrja)
        {
            this.timi_byrja = timi_byrja;
        }

        public void setTimiEndir(string timi_endir)
        {
            this.timi_endir = timi_endir;
        }

        public void setVettvangur(string vettvangur)
        {
            this.vettvangur = vettvangur; 
        }

       /* public int getNumber()
        {
            return number;
        }*/

        public string getByrja()
        {
            return byrja;     
        }

        public string getEndir()
        {
            return endir;
        }

        public string getVettvangur()
        {
            return vettvangur;
        }
        #endregion 
    
        #region "Functions"
        public void virkjaDagur()
        {
            dt = DateTime.Now;
            day_DateTime_Now = dt.Day;
            month_DateTime_Now = dt.Month;
            year_DateTime_Now = dt.Year;
        }

        public void skiptaDagur(string byrja_)
        {
            dagur = byrja_.Split('.');
            day = Int32.Parse(dagur[0]);
            month = Int32.Parse(dagur[1]);
            year = Int32.Parse(dagur[2]);
        }

        public void writeMonthString()
        {
            if (month == 1) { monthString = "Janúar";    }
            if (month == 2) { monthString = "Febrúar";   }
            if (month == 3) { monthString = "Mars";      }
            if (month == 4) { monthString = "Apríl";     }
            if (month == 5) { monthString = "Maí";       }
            if (month == 6) { monthString = "Júní";      }
            if (month == 7) { monthString = "Júlí";      }
            if (month == 8) { monthString = "Ágúst";     }
            if (month == 9) { monthString = "September"; }
            if (month == 10) { monthString = "Október";  }
            if (month == 11) { monthString = "Nóvember"; }
            if (month == 12) { monthString = "Desember"; }
        }

        public void SkraVinnaNeydarsimi()
        {
            SkraNeydarsimi();
            SkraVinna(); 
        }

        public void SkraNeydarsimi()
        {
            string sqlString = "INSERT INTO NEYDARSIMI(BYRJA,ENDIR, TIMI_BYRJA, TIMI_ENDIR,TEGUND) VALUES('" + byrja + "','" + endir + "','" + timi_byrja + "','" + timi_endir + "','" + vettvangur + "');";
            clsDatabase.ExcuteQuery(sqlString); 
        }

        public void SkraVinna()
        {
            string sqlString = "INSERT INTO VINNA(KT) VALUES('" + kennitala + "') ;";
            clsDatabase.ExcuteQuery(sqlString); 
        }

        public void HladaNeydarsimi(ListView listView1, string byrja)
        {
            numer = 0; 
            virkjaDagur(); 
            listView1.Items.Clear();

            string sqlString = "SELECT NAFN, BYRJA, ENDIR, TIMI_BYRJA, TIMI_ENDIR, TEGUND FROM TULKUR, VINNA, NEYDARSIMI WHERE TULKUR.KT=VINNA.KT AND VINNA.NR=NEYDARSIMI.NR ORDER BY NEYDARSIMI.NR DESC;";
            clsDatabase.GetRecord(sqlString);

            while (reader.Read())
            {
                numer++;
                list = new ListViewItem( numer.ToString() );

                list.SubItems.Add(reader["NAFN"].ToString());

                skiptaDagur( reader["BYRJA"].ToString() );
                writeMonthString(); 
                //------------------------------------------------------------
                if(month_DateTime_Now <= month && year_DateTime_Now <= year)
                {
                   if (day_DateTime_Now <= day || month_DateTime_Now < month)
                   {
                      list.BackColor = System.Drawing.Color.Gold;
                      strengur = day + " " + monthString + " " + year;
                      list.SubItems.Add(strengur);
                   }
                   else
                   {
                      list.BackColor = System.Drawing.Color.Firebrick;
                      strengur = day + " " + monthString + " " + year;
                      list.SubItems.Add(strengur);
                   }
                }
                else
                {
                    list.BackColor = System.Drawing.Color.Firebrick;
                    strengur = day + " " + monthString + " " + year;
                    list.SubItems.Add(strengur);
                }
                //------------------------------------------------------------
                skiptaDagur( reader["ENDIR"].ToString() );
                writeMonthString();
                strengur = day + " " + monthString + " " + year;
                list.SubItems.Add(strengur);

                list.SubItems.Add(reader["TIMI_BYRJA"].ToString());
                list.SubItems.Add(reader["TIMI_ENDIR"].ToString());
                list.SubItems.Add(reader["TEGUND"].ToString());



                listView1.Items.Add(list);
                  
            }
            reader.Close();
        }
        #endregion 
    }
}
